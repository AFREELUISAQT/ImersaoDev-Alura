var ola = "Olá! "
var nome = "Eu sou a LuisaQT"
var descripcao = "Minha Nota alcançada na Aula 01 da Imersão Dev da Alura é: "
var relatorio = ", correspondendo a uma porcentagem de: "

var notaAula1 = 10
var porcentagem = 100

var notaFinal = (notaAula1 * porcentagem) / 10

console.log(ola + "Bem-vind@s! " + nome)
console.log (descripcao + notaAula1 + relatorio + notaFinal + "%")