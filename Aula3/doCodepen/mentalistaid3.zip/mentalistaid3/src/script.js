var numeroSecreto = parseInt(Math.random() * 11);

function Chutar() {
  
  var elementoResultado = document.getElementById("resultado");

  var chute = parseInt(document.getElementById("valor").value);
  
  if (chute == numeroSecreto) {
    elementoResultado.innerHTML = "Vocé acertou! O Número Secreto é: " + numeroSecreto;
  } else if (chute > numeroSecreto) {
    elementoResultado.innerHTML = "O número Secreto é maior ao Digitado!";
  }  else if (chute < numeroSecreto) {
    elementoResultado.innerHTML = "O número Secreto é menor ao Digitado!";
  } else (chute > 10 || chute < 0) {
    elementoResultado.innerHTML = "Vocé deve digitar um número de 0 a 10!";
  };
};


//    else {
//    elementoResultado.innerHTML =
//    "Você errou! O número Secreto era " + numeroSecreto;
//}
